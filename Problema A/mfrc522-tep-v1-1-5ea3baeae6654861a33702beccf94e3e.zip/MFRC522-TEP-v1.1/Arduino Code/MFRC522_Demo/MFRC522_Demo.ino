/*
  MFRC522 RFID Reader - Arduino UNO demo for the TEP Proteus library (v1.1)
  The Engineering Projects - www.TheEngineeringProjects.com

  Wiring (as in MFRC522-ArduinoUnoV3.pdsprj, the same on both UNOs):
    3V3 -> supply rail (a real RC522 board needs 3.3 V)   GND -> GND
    SCK -> D13   MISO -> D12   MOSI -> D11   SDA (SS) -> D10   RST -> D9   IRQ -> not used
    LED + 220 ohm from A0 to GND: lights for 3 s when a card is allowed (ACCESS GRANTED)
    Arduino D1/TX -> Serial Monitor RXD, Arduino D0/RX <- Serial Monitor TXD (9600 8N1)

  Uses the standard "MFRC522" library by GithubCommunity (miguelbalboa), v1.4.x, unmodified.
  In the simulation click CARD 1..4 on the reader panel (or Tap / Hold in the Advance window) to place a card.
  Cards 1 and 2 are allowed at start; cards 3 and 4 are denied - add them with ADD.

  Serial Monitor commands (v1.1):
    HELP            the command list
    STATUS          reads, the allowed UIDs, key, antenna, LED, reader version
    ADD [uid]       allow the last card read (or a UID typed in hex, 8 or 14 digits)
    DEL [uid]       remove the last card read (or that UID) from the allowed list
    DUMP            the next card's whole memory (PICC_DumpToSerial)
    KEY A / KEY B   which MIFARE key (FF FF FF FF FF FF) opens sector 0 for the block 1 read
    ANTENNA ON|OFF  switch the reader's RF field
*/
#include <Arduino.h>
#include <SPI.h>
#include <MFRC522.h>

#define SS_PIN  10
#define RST_PIN 9
#define LED_PIN A0
const unsigned long LED_MS = 3000;
const byte MAX_ALLOWED = 8;

MFRC522 rfid(SS_PIN, RST_PIN);
MFRC522::MIFARE_Key key;

struct AllowedUid { byte size; byte uid[7]; };
AllowedUid allowed[MAX_ALLOWED] = { {4, {0xDE, 0xAD, 0xBE, 0xEF}}, {4, {0x12, 0x34, 0x56, 0x78}} };
byte allowedCount = 2;
unsigned long readCount = 0;
byte lastUid[7];
byte lastSize = 0;
bool useKeyB = false, dumpNext = false, antennaOn = true, ledOn = false;
unsigned long ledOffAt = 0;
char line[40];
byte lineLen = 0;

void printHex(const byte* data, byte length) {
  for (byte i = 0; i < length; i++) {
    if (data[i] < 0x10) Serial.print('0');
    Serial.print(data[i], HEX);
    if (i + 1 < length) Serial.print(' ');
  }
}

int findAllowed(const byte* uid, byte size) {
  for (byte i = 0; i < allowedCount; i++)
    if (allowed[i].size == size && memcmp(allowed[i].uid, uid, size) == 0) return i;
  return -1;
}

bool isAuthorised(const MFRC522::Uid& uid) {
  return findAllowed(uid.uidByte, uid.size) >= 0;
}

void printHelp() {
  Serial.println(F("Serial Monitor: HELP, STATUS, ADD [uid], DEL [uid], DUMP, KEY A, KEY B, ANTENNA ON / OFF"));
}

void printStatus() {
  Serial.print(F("Status: ")); Serial.print(readCount); Serial.print(F(" reads, "));
  Serial.print(allowedCount); Serial.print(F(" allowed, key ")); Serial.print(useKeyB ? 'B' : 'A');
  Serial.print(F(", antenna ")); Serial.print(antennaOn ? F("on") : F("off"));
  Serial.print(F(", LED ")); Serial.print(ledOn ? F("on") : F("off"));
  Serial.print(F(", reader 0x")); Serial.println(rfid.PCD_ReadRegister(MFRC522::VersionReg), HEX);
  for (byte i = 0; i < allowedCount; i++) { Serial.print(F("  allowed: ")); printHex(allowed[i].uid, allowed[i].size); Serial.println(); }
}

// "DE AD BE EF", "DEADBEEF" or "04 11 22 33 44 55 66" -> bytes; returns the count (4 or 7) or 0
byte parseUid(const char* s, byte* out) {
  byte n = 0; int hi = -1;
  for (; *s; s++) {
    char c = toupper(*s);
    if (c == ' ' || c == ':' || c == '-') continue;
    int v = (c >= '0' && c <= '9') ? c - '0' : (c >= 'A' && c <= 'F') ? c - 'A' + 10 : -1;
    if (v < 0 || n >= 7) return 0;
    if (hi < 0) hi = v; else { out[n++] = byte(hi << 4 | v); hi = -1; }
  }
  return (hi < 0 && (n == 4 || n == 7)) ? n : 0;
}

void command(char* cmd) {
  for (char* p = cmd; *p; p++) *p = toupper(*p);
  char* arg = strchr(cmd, ' ');
  if (arg) { *arg++ = 0; while (*arg == ' ') arg++; }
  byte uid[7]; byte size = 0;
  if (!strcmp(cmd, "HELP")) printHelp();
  else if (!strcmp(cmd, "STATUS")) printStatus();
  else if (!strcmp(cmd, "ADD") || !strcmp(cmd, "DEL")) {
    if (arg && *arg) { size = parseUid(arg, uid); if (!size) { Serial.println(F("Give the UID as 8 or 14 hex digits, e.g. ADD A1B2C3D4")); return; } }
    else if (lastSize) { size = lastSize; memcpy(uid, lastUid, size); }
    else { Serial.println(F("Read a card first (or type ADD / DEL with a UID)")); return; }
    int at = findAllowed(uid, size);
    if (cmd[0] == 'A') {
      if (at >= 0) { Serial.print(F("Already allowed: ")); printHex(uid, size); Serial.println(); return; }
      if (allowedCount >= MAX_ALLOWED) { Serial.println(F("The list is full (8 UIDs) - DEL one first")); return; }
      allowed[allowedCount].size = size; memcpy(allowed[allowedCount].uid, uid, size); allowedCount++;
      Serial.print(F("Added ")); printHex(uid, size); Serial.print(F(" (")); Serial.print(allowedCount); Serial.println(F(" allowed)"));
    } else {
      if (at < 0) { Serial.print(F("Not in the list: ")); printHex(uid, size); Serial.println(); return; }
      for (byte i = at; i + 1 < allowedCount; i++) allowed[i] = allowed[i + 1];
      allowedCount--;
      Serial.print(F("Removed ")); printHex(uid, size); Serial.print(F(" (")); Serial.print(allowedCount); Serial.println(F(" allowed)"));
    }
  }
  else if (!strcmp(cmd, "DUMP")) { dumpNext = true; Serial.println(F("DUMP: place a card - its whole memory is printed")); }
  else if (!strcmp(cmd, "KEY") && arg && (*arg == 'A' || *arg == 'B') && !arg[1]) {
    useKeyB = *arg == 'B';
    Serial.print(F("Sector 0 is now opened with key ")); Serial.print(useKeyB ? 'B' : 'A'); Serial.println(F(" (FF FF FF FF FF FF)"));
  }
  else if (!strcmp(cmd, "ANTENNA") && arg && (!strcmp(arg, "ON") || !strcmp(arg, "OFF"))) {
    antennaOn = arg[1] == 'N';
    if (antennaOn) rfid.PCD_AntennaOn(); else rfid.PCD_AntennaOff();
    Serial.println(antennaOn ? F("Antenna on - the reader looks for cards") : F("Antenna off - no card gets power"));
  }
  else if (*cmd) { Serial.print(F("Unknown command: ")); Serial.print(cmd); Serial.println(F(" - type HELP")); }
}

void readSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\r' || c == '\n') { if (lineLen) { line[lineLen] = 0; command(line); lineLen = 0; } }
    else if (lineLen < sizeof(line) - 1) line[lineLen++] = c;
  }
}

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  Serial.begin(9600);
  SPI.begin();
  rfid.PCD_Init();
  for (byte i = 0; i < 6; i++) key.keyByte[i] = 0xFF;   // factory default key

  Serial.println(F("TEP MFRC522 RFID Reader Demo v1.1"));
  Serial.print(F("Reader firmware: "));
  rfid.PCD_DumpVersionToSerial();
  Serial.println(F("Authorised: DE AD BE EF, 12 34 56 78"));
  Serial.println(F("Click a card on the reader panel..."));
  printHelp();
}

void loop() {
  readSerial();
  if (ledOn && (long)(millis() - ledOffAt) >= 0) { digitalWrite(LED_PIN, LOW); ledOn = false; }

  if (!rfid.PICC_IsNewCardPresent()) return;   // REQA every loop; a card answers once placed
  if (!rfid.PICC_ReadCardSerial()) return;     // anticollision + select

  readCount++;
  lastSize = rfid.uid.size; memcpy(lastUid, rfid.uid.uidByte, lastSize);
  Serial.println();
  Serial.print(F("Read #")); Serial.println(readCount);
  Serial.print(F("  UID : ")); printHex(rfid.uid.uidByte, rfid.uid.size); Serial.println();
  Serial.print(F("  SAK : 0x")); Serial.println(rfid.uid.sak, HEX);
  MFRC522::PICC_Type type = rfid.PICC_GetType(rfid.uid.sak);
  Serial.print(F("  Type: ")); Serial.println(rfid.PICC_GetTypeName(type));

  if (dumpNext) {                               // DUMP: the whole memory (the library halts the card itself)
    dumpNext = false;
    rfid.PICC_DumpToSerial(&rfid.uid);
    Serial.println(isAuthorised(rfid.uid) ? F("  -> ACCESS GRANTED") : F("  -> ACCESS DENIED"));
    return;
  }

  // MIFARE Classic: authenticate sector 0 and read block 1 (the demo text)
  if (type == MFRC522::PICC_TYPE_MIFARE_1K || type == MFRC522::PICC_TYPE_MIFARE_4K || type == MFRC522::PICC_TYPE_MIFARE_MINI) {
    MFRC522::StatusCode status = rfid.PCD_Authenticate(useKeyB ? MFRC522::PICC_CMD_MF_AUTH_KEY_B : MFRC522::PICC_CMD_MF_AUTH_KEY_A, 1, &key, &rfid.uid);
    if (status == MFRC522::STATUS_OK) {
      byte buffer[18]; byte size = sizeof(buffer);
      status = rfid.MIFARE_Read(1, buffer, &size);
      if (status == MFRC522::STATUS_OK) {
        Serial.print(F("  Block 1: ")); printHex(buffer, 16);
        Serial.print(F("  \"")); for (byte i = 0; i < 16; i++) Serial.print(buffer[i] >= 32 && buffer[i] < 127 ? (char)buffer[i] : '.'); Serial.println('"');
      } else { Serial.print(F("  MIFARE_Read failed: ")); Serial.println(rfid.GetStatusCodeName(status)); }
    } else { Serial.print(F("  Authentication failed: ")); Serial.println(rfid.GetStatusCodeName(status)); }
  }
  // Ultralight / NTAG (v1.1): pages 4-7 need no key
  else if (type == MFRC522::PICC_TYPE_MIFARE_UL) {
    byte buffer[18]; byte size = sizeof(buffer);
    MFRC522::StatusCode status = rfid.MIFARE_Read(4, buffer, &size);
    if (status == MFRC522::STATUS_OK) {
      Serial.print(F("  Pages 4-7: ")); printHex(buffer, 16);
      Serial.print(F("  \"")); for (byte i = 0; i < 16; i++) Serial.print(buffer[i] >= 32 && buffer[i] < 127 ? (char)buffer[i] : '.'); Serial.println('"');
    } else { Serial.print(F("  MIFARE_Read failed: ")); Serial.println(rfid.GetStatusCodeName(status)); }
  }

  if (isAuthorised(rfid.uid)) {
    Serial.println(F("  -> ACCESS GRANTED"));
    digitalWrite(LED_PIN, HIGH); ledOn = true; ledOffAt = millis() + LED_MS;
  } else Serial.println(F("  -> ACCESS DENIED"));

  rfid.PICC_HaltA();        // card stays silent until it is removed and placed again
  rfid.PCD_StopCrypto1();
}
