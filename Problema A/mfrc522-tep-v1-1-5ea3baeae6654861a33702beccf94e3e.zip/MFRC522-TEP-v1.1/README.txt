MFRC522 RFID READER (RFID-RC522 module) LIBRARY FOR PROTEUS - V1.1
Designed by The Engineering Projects
www.TheEngineeringProjects.com

IMPORTANT LINKS
Article (read it first - pictures, step by step, every feature explained):
  https://www.theengineeringprojects.com/2026/09/mfrc522-rfid-proteus-library.html
Report a bug or suggest a feature (our forum):
  https://www.theengineeringprojects.com/forum/category/mfrc522-proteus-library
The demo uses our TEP Serial Monitor Advance (included) instead of Proteus's
Virtual Terminal - its own article:
  https://www.theengineeringprojects.com/2026/10/serial-monitor-advance-proteus-library.html
Support us (the libraries are free):
  https://www.theengineeringprojects.com/donate

FILE STRUCTURE
MFRC522-TEP-v1.1/
|-- Proteus Library Files/
|   |-- ArduinoV3TEP.IDX                              0.8 KB   its index -> LIBRARY folder
|   |-- ArduinoV3TEP.LIB                             95.6 KB   TEP Arduino UNO (demo) -> LIBRARY folder
|   |-- TEPMFRC522.LIB                               92.2 KB   MFRC522 Simple + Advance (2 devices) -> LIBRARY folder
|   |-- TEPSERIALMON.LIB                             11.1 KB   TEP Serial Monitor Advance -> LIBRARY folder
|-- Proteus Model Files/
|   |-- TEPMFRC522.DLL                              336.5 KB   MFRC522 model -> MODELS folder
|   |-- TEPSERIALMON.DLL                            978.0 KB   Serial Monitor model -> MODELS folder
|-- Proteus Simulation/
|   |-- MFRC522_Demo.hex                             37.5 KB   both UNOs (access control v1.1)
|   |-- MFRC522-ArduinoUnoV3.pdsprj                  25.6 KB   demo: UNO 1 + MFRC522 Simple, UNO 2 + Advance
|   |-- TEPMFRC522.DLL                              336.5 KB   copy of the model so the demo runs as is
|   |-- TEPSERIALMON.DLL                            978.0 KB   copy of the monitor model
|-- Arduino Code/
|   |-- MFRC522_Demo/MFRC522_Demo.ino                 9.5 KB   sketch (source of the .hex)
|   |-- libraries/MFRC522/                          166.3 KB   MFRC522 1.4.12 (Unlicense, UNLICENSE), 12 files
|-- README.txt                                      ~31.5 KB   this file
Total: 3.03 MB (unzipped). The C++ source code of the model is not included.

WHAT IS IT?
A simulation model of the NXP MFRC522 13.56 MHz RFID reader on the common blue
RFID-RC522 board for Proteus 8. Your Arduino talks to it over SPI exactly as to
the real one: the popular MFRC522 Arduino library (GithubCommunity /
miguelbalboa) runs unmodified - PCD_Init, PICC_IsNewCardPresent,
PICC_ReadCardSerial, PCD_Authenticate, MIFARE_Read / Write, value blocks,
PICC_DumpToSerial, even PCD_PerformSelfTest. The model has the chip's
registers, FIFO, CRC coprocessor, timer and IRQ pin, and the cards answer like
real ISO 14443-3A cards: MIFARE Classic 1K and 4K (keys and access bits in
every sector trailer), MIFARE Ultralight and NTAG213. You place cards on the
reader with a click. The part looks like the blue RFID-RC522 board with its
PCB antenna, the MFRC522 chip, the 27.12 MHz crystal and the red PWR LED;
while the simulation runs the PWR LED lights, the antenna loop glows cyan
while the reader's RF field is on and green while a card answers, the waves
above it follow, and the card on the reader is drawn on the antenna with its
number, UID and state. Under PWR sits a green CARD LED that flashes on every
card exchange (a TEP addition - the real RC522 board has only the power LED).

TWO DEVICES IN ONE LIBRARY (search "MFRC522" or "RFID" in Pick Devices):
  MFRC522 Simple    device MFRC522TEP     "MFRC522 RFID Reader Module (RFID-RC522) - Simple"
                    On-Sheet Panel: a card panel on the schematic next to the
                    reader - the reader's state, CARD 1 .. CARD 4 (click one to
                    hold it on the reader; click it again to place it again),
                    REMOVE CARD and the last exchanges with the card. The red X
                    in the panel's header closes it, the PANEL button on the
                    board opens it again. Your v1.0 designs keep working with
                    this device.
  MFRC522 Advance   device MFRC522ADVTEP  "MFRC522 RFID Reader Module (RFID-RC522) - Advance"
                    Pop-Up Panel: only the reader board on the schematic; at Run
                    a TEP pop-up window opens - the same look as the TEP Serial
                    Monitor (move it by its header, resize it, minimise it). The
                    tabs Cards and Test sit in the header; the gear and ? icons
                    open Settings and Help; the palette icon switches the theme:
                      Cards     the card wallet: the READER card (field on / off,
                                the card in the field and its state, reads and
                                the last UID, VersionReg and the SPI clock), the
                                four cards with Tap (0.5 s on the reader) and
                                Hold (until removed), Remove the card, and an
                                editor: the card's type (1K, 4K, UL, NTAG213),
                                its UID typed with a hex keypad (or Random),
                                Apply; its memory block by block (Classic) or 4
                                pages at a time (Ultralight / NTAG) with the
                                keys and access bits of the sector, presets
                                (Text, Zeros, Value 100) and Write
                      Test      four tools measured on the model with your
                                sketch: Read test, Card types, Authentication,
                                Register check (see THE TEST TOOLS below)
                      Settings  theme (TEP Dark / Light), text size, open at Run,
                                window size - remembered for your Windows user
                      Help      Help & Support like the TEP Serial Monitor: report
                                a bug, suggest a feature, article, user guide,
                                updates, donate, website, forum; Copy diagnostics
                                (reader, registers, cards, test results) for a
                                bug report
                    The OPEN PANEL button on the board opens the window again
                    after you close it.
Both devices use the same model (TEPMFRC522.DLL) and the same properties.

NEW IN V1.1
* Two devices: MFRC522 Simple (card panel on the sheet, close / open) and
  MFRC522 Advance (pop-up window with the card wallet and editor, four test
  tools, settings and help) - see above.
* Board: the real board's look made bigger - the PCB antenna loop is the big
  part it is on a real RFID-RC522 - with the red PWR LED of the real board, an
  antenna glow (cyan = field on, green = a card answers), waves above the
  antenna, the card drawn on the antenna, a PANEL / OPEN PANEL button and a
  SIMPLE / ADVANCE badge. The board keeps the v1.0 blue.
* Board - CARD LED (a TEP addition; the real RC522 board has only the power
  LED): a green activity LED under PWR, driven by the model. It lights when a
  card answers the reader (REQA / WUPA answered, anticollision, SELECT,
  authentication, READ / WRITE) and stays lit 0.35 s (simulation time) after
  the last answer, so every read is a visible blink; it stays dark while no
  card answers (no card, the antenna off, a halted card that only hears REQA).
* Model - time: the reader now takes the real time. A frame nobody answers
  (no card, a halted card, a wrong key, HLTA) ends with the chip's timer after
  25 ms (the library's TPrescaler / TReload setting), as on real hardware;
  v1.0 answered "no card" at once. The answers take their air time at 106
  kbit/s (REQA + ATQA 0.36 ms, SELECT about 1.1 ms, authentication 1.95 ms,
  READ 2.0 ms, a MIFARE write 2.5 ms of EEPROM time). TCounterValReg counts.
* Model - RF field: with the antenna off (before PCD_Init, after a reset or
  PCD_AntennaOff) no card gets power and none answers; switching the field off
  and on restarts the card in it. A card left selected (not halted) goes back
  to IDLE on the next REQA and answers the one after - the library's well-known
  "found every other loop" behaviour.
* Model - cards: MIFARE Classic 4K (SAK 18, 40 sectors) and NTAG213 (45 pages,
  NDEF text record, GET_VERSION) besides Classic 1K and Ultralight; property
  TYPEn chooses (AUTO = from the UID length, as in v1.0). The keys and access
  bits now live in every sector trailer: KEYA / KEYB set them at the start, a
  sketch that writes a trailer changes that sector's keys like on a real card,
  the access-condition table of the MIFARE Classic data sheet is enforced
  (read / write / increment / decrement per block, a readable key B cannot be
  used - authentication works, every access gets NAK), INC / DEC check the
  value-block format; Ultralight / NTAG page 3 and the lock bytes are
  OR-written (one-time programmable).
* Model - chip: the self test (PCD_PerformSelfTest) passes; property CHIPVER
  gives VersionReg 0x92 (v2.0, default), 0x91 (v1.0) or 0x88 (the FM17522
  clone); the IRQ pin is open drain after a reset (data sheet DivIEnReg 00h;
  v1.0 drove it push-pull).
* The demo uses the TEP Serial Monitor Advance instead of the Virtual
  Terminal - one monitor per Arduino (U3 = UNO 1, U4 = UNO 2) with quick
  buttons - and shows both styles: UNO 1 with MFRC522 Simple, UNO 2 with
  MFRC522 Advance, an access LED on A0 of each UNO.
* The demo sketch (v1.1) keeps every v1.0 line and adds: the access LED (3 s on
  ACCESS GRANTED), an allowed list you change from the Serial Monitor (ADD /
  DEL, with or without a UID), STATUS, DUMP (the next card's whole memory), KEY
  A / KEY B, ANTENNA ON / OFF, HELP; Ultralight / NTAG cards show their pages
  4-7.
* Version 1.1 everywhere; the C++ source code is no longer included (and
  neither is the Arduino AVR core archive - its GitHub link is below).

TEST STATUS
v1.1 was tested in Proteus 8.5 SP0 (6 Oct 2026) with this package's demo: both
Serial Monitors and the Advance pop-up open at Run (no system caption row); both
sketches print the banner and Firmware Version 0x92 = v2.0. U1 (Simple): CARD 1
(ACCESS GRANTED, D1 lights, the card shows HALTED on the antenna), CARD 3
(Ultralight, DENIED), CARD 4 DENIED -> ADD on the Serial Monitor -> CARD 4
GRANTED, the red X and PANEL. U2 (Advance): Tap / Hold / Remove on the Cards
page, Test > Read test x 5 (5 / 5, UID after 13.7 ms on average, block read
19.6 ms), Card types (4 / 4: Classic 1K, 4K, Ultralight, NTAG213), Authentication
with key A changed (no answer, timer 26.53 ms), Register check (SPI 4.00 MHz),
Settings, Help, close and OPEN PANEL.
The green CARD LED was added after that test (6 Oct 2026, at the owner's
request for activity LEDs on all boards) and checked in a second Proteus run
the same day: dark with no card, a green flash while CARD 1 is read, dark again
once the card is halted; PWR stays red.
PC tests:
  1639 automatic checks on a PC, 0 failed: 104 with the unmodified MFRC522
  library driving the chip model bit by bit over SPI (the 33 of v1.0,
  unchanged, plus 71 for v1.1: the timer and air times, the RF field, the 4K
  and NTAG213 cards, keys and access bits, value blocks, the self test, the
  chip versions, taps); 57 with the real v1.1 demo sketch (every v1.0 output
  line, the LED, every Serial Monitor command, the card types, a wrong key, the
  three test tools); 88 on the complete Proteus model (the 9 of v1.0 on a
  design with the v1.0 symbol plus both devices, the panel's red X / PANEL, the
  pop-up and its Cards page, the board's PWR and CARD LEDs / antenna glow /
  card, the properties, RST, power and IRQ, the tools through the pop-up);
  1390 on the rendered boards and pop-up windows (the CARD LED lit / dark;
  every page fits in TEP Dark and Light, at Large text and 150 % DPI; every
  tool's hint lines fit the window).
v1.0: the v1.0 demo project was opened, re-wired, run and saved in Proteus 8.5
  on 29 Sep 2026 (the project in the v1.0 package is Proteus-written); no other
  record of a v1.0 Proteus test exists.

INSTALLATION (about 2 minutes)
1. Close Proteus. Extract the WHOLE ZIP to a normal folder (e.g. Desktop).
2. Copy everything in "Proteus Library Files" (TEPMFRC522.LIB with both
   devices, TEPSERIALMON.LIB and the TEP Arduino UNO V3 library
   ArduinoV3TEP.LIB / .IDX used by the demo) to the LIBRARY folder of Proteus,
   for example:
     C:\Program Files (x86)\Labcenter Electronics\Proteus 8 Professional\LIBRARY
   (on some PCs: C:\ProgramData\Labcenter Electronics\Proteus 8 Professional\
   LIBRARY - use the folder that already holds Proteus's own .LIB files).
3. Copy TEPMFRC522.DLL and TEPSERIALMON.DLL from "Proteus Model Files" to the
   MODELS folder (...\Proteus 8 Professional\MODELS).
4. Updating from v1.0: replace TEPMFRC522.LIB and TEPMFRC522.DLL, and delete
   TEPMFRC522.IDX if there is one in the LIBRARY folder. A v1.0 design keeps
   its v1.0 symbol: it runs with the new model and shows the v1.0 panel
   (without the v1.1 board parts and the red X) - re-pick the part to get the
   v1.1 symbol.
5. Start Proteus. In Pick Devices (P) search "MFRC522": you get the Simple and
   the Advance device (category Sensors > RFID).

RUN THE DEMO
"Proteus Simulation\MFRC522-ArduinoUnoV3.pdsprj" - keep the .hex file and the
two DLLs beside the project. Both UNOs run MFRC522_Demo.hex.
  UNO 1 (ARD1): MFRC522 Simple (U1) and Serial Monitor U3.
  UNO 2 (ARD2): MFRC522 Advance (U2) and Serial Monitor U4.
  An LED (D1 / D2) with 220 ohm on A0 of each UNO: the access LED.
  1. Press Run. Both monitor windows open (9600 baud) and so does U2's pop-up.
     The monitors show "TEP MFRC522 RFID Reader Demo v1.1", "Reader firmware:
     Firmware Version: 0x92 = v2.0", the allowed cards and the command list.
     Both antennas turn cyan: the field is on.
  2. U1: click CARD 1 on the panel beside the reader - U3 prints "Read #1", the
     UID DE AD BE EF, SAK 0x8, "MIFARE 1KB", block 1 "TEP RFID DEMO 09" and
     "-> ACCESS GRANTED"; LED D1 lights for 3 s; the antenna and the board's
     CARD LED flash green, the card on the antenna says HALTED (the sketch
     halted it, so it is read once).
     CARD 3 (Ultralight) and CARD 4 are denied. REMOVE CARD takes the card away.
     Close the panel with its red X and open it with PANEL on the board.
  3. U3 / U4 quick buttons: STATUS, ADD (allow the last card read - read CARD 4,
     ADD, read it again: granted), DEL (remove it again), DUMP (the next card's
     whole memory). Type HELP, KEY B (sector 0 with key B: a transport card
     refuses it - "MIFARE_Read failed: A MIFARE PICC responded with NAK."), KEY
     A, ANTENNA OFF / ON, ADD 04112233445566.
  4. U2 (Advance): Cards page - Tap / Hold the cards and watch the READER card.
     Click CARD 4 to edit it: choose NTAG213, Apply, then Hold it - the sketch
     prints its pages 4-7 (the NDEF record). Type a new UID with the keypad
     (Apply), or step to a block, choose Text and Write it. Test page:
       Read test: card 1, 0.5 s, 5 runs - each tap is detected within one
         REQA cycle (about 26 ms), the UID 2.5 ms later, the block 1 read 7 ms
         after that, and HLTA about 100 ms later (the sketch's Serial prints).
       Card types: the four test cards and what the sketch does with each.
       Authentication: Keys as set / Key A changed (no answer, 26.5 ms) / Key B
         only (READ refused); then type KEY B on U4 and run Key B only again.
       Register check: the registers your sketch set and its SPI traffic.
  5. Close U2's window and open it again with OPEN PANEL on the board.
Closed a monitor window? Click OPEN MONITOR on the monitor part.

WIRING (SPI, the same on both UNOs - as in the v1.0 demo)
  MFRC522 3V3 -> supply, GND -> GND, SCK -> D13, MISO -> D12, MOSI -> D11,
  SDA (the chip select, SS) -> D10, RST -> D9, IRQ not connected.
  LED + 220 ohm from A0 to GND (the access LED).
  Serial Monitor RXD <- Arduino D1 (TX), Serial Monitor TXD -> Arduino D0 (RX),
  Serial Monitor GND -> ground. RXD2 is not needed: the reader is an SPI device,
  there is no serial line between the reader and the Arduino to watch.
In the sketch: MFRC522 rfid(10, 9);  SPI.begin();  rfid.PCD_Init();  Serial 9600.
Pin order in Proteus: 3V3 GND SCK MISO MOSI SDA RST IRQ (v1.0). The header on
the real board reads SDA SCK MOSI MISO IRQ GND RST 3.3V - wire by the names.
In the simulation the 3V3 pin is wired to the power terminal (the default 5 V
rail); the model only checks that the pin is powered.
REAL HARDWARE:
 * The RFID-RC522 is a 3.3 V module: feed 3V3 from the Arduino's 3.3 V pin (it
   draws up to about 26 mA), never from 5 V.
 * The UNO's SPI outputs (SCK, MOSI, SDA / SS, RST) are 5 V signals; the
   MFRC522's inputs are specified up to its 3.3 V supply. Use a level shifter
   (or 1 k / 2 k dividers on SCK, MOSI, SS and RST) - many boards survive 5 V
   for a while, but it is out of spec. MISO (3.3 V) is read correctly by the UNO.
 * IRQ is open drain after a reset (active LOW with the default IRqInv): add a
   pull-up (10 k to 3.3 V) if you use it, and wire it to D2 or D3 (INT0 / INT1).
 * Range: a few centimetres with the board's PCB antenna; metal near the antenna
   detunes it. The simulation has no distance - a card is in the field or not.

THE CARDS
Default cards (properties UID1..UID4 and TYPE1..TYPE4):
  CARD 1  DE AD BE EF           MIFARE Classic 1K   allowed in the demo
  CARD 2  12 34 56 78           MIFARE Classic 1K   allowed in the demo
  CARD 3  04 11 22 33 44 55 66  MIFARE Ultralight   denied (ADD allows it)
  CARD 4  A1 B2 C3 D4           MIFARE Classic 1K   denied (ADD allows it)
MIFARE Classic 1K: 16 sectors of 4 blocks; block 0 holds the UID, BCC, SAK and
ATQA (read-only), block 1 the demo text "TEP RFID DEMO 0n", every sector
trailer key A (KEYA), the transport access bits FF 07 80 69 and key B (KEYB).
MIFARE Classic 4K: the same, 32 sectors of 4 blocks + 8 sectors of 16 blocks.
MIFARE Ultralight: 7-byte UID, 16 pages of 4 bytes, no keys.
NTAG213: 7-byte UID, 45 pages, an NDEF text record "TEP RFID DEMO" in its user
memory, GET_VERSION answers 00 04 04 02 01 00 0F 03; the library reports it as
"MIFARE Ultralight or Ultralight C" (both answer SAK 00).
Writes stay while the simulation runs; every new run starts with fresh cards.
Card states (panel / pop-up): in the field (IDLE, waiting for REQA), answered
REQA, selected by the reader, halted by the reader.

THE TEST TOOLS (MFRC522 Advance, Test tab) - what they really measure
Every tool runs on the live model with your sketch. A tool only places cards
in the field and reads the reader's own log - it never talks to your Arduino -
so every time is what your sketch's SPI traffic and the card really did,
measured with the simulation clock. Each tool shows one "Good for:" line and
one line on how it measures.
  Read test       Taps card 1-4 on the reader 3, 5 or 10 times (0.2, 0.5 or 1 s
                  in the field, 1 s apart) and times each step from the tap: REQA
                  answered (detected), SELECT done (the UID is in your Arduino),
                  the first AUTH, the first READ (ok / NAK), HLTA (your sketch is
                  done with the card). Example with the demo sketch, 0.5 s taps:
                  detected 4 - 13 ms (it depends where your loop() is: a REQA
                  without a card waits 25 ms for the timer), UID 2.5 ms later,
                  AUTH 4.4 ms after that, READ 2.3 ms later, HLTA about 100 ms
                  later - the Serial prints at 9600 baud. A card that leaves
                  before the read shows what your sketch missed. Your
                  Serial.print time is not on the bus - only its effect is.
  Card types      Holds a Classic 1K, a Classic 4K, an Ultralight and an NTAG213
                  test card 1 s each and lists ATQA / SAK, the UID size and
                  cascade levels, and every command your sketch sent to the card
                  with its answer (e.g. "REQA, SELECT (4 B UID), AUTH A 1 ok,
                  READ 1 ok, HLTA" for the 1K; "REQA, SELECT (7 B UID), READ 4 ok,
                  HLTA" for the Ultralight / NTAG with the demo sketch), plus what
                  the library's PICC_GetType reports for that SAK.
  Authentication  A Classic 1K test card in three set-ups: Keys as set (KEYA /
                  KEYB, transport access bits), Key A changed (A0 A1 A2 A3 A4 A5
                  on the card), Key B only (access bits 0F 00 FF: the data blocks
                  need key B, key B is secret). Per run: the key your sketch sent
                  (A or B and its six bytes - read from the MFAuthent command),
                  the block, the card's key, the answer (ok in 1.95 ms, or no
                  answer: the reader's timer ends it after 26.5 ms =
                  STATUS_TIMEOUT) and what the READ that followed got (16 bytes
                  or NAK). With the demo: Keys as set ok / ok, Key A changed no
                  answer, Key B only ok / NAK; after KEY B on the monitor, Key B
                  only ok / ok.
  Register check  The MFRC522's registers now, decoded: CommandReg (the
                  command), ComIEnReg (IRQ polarity), ComIrqReg / DivIrqReg /
                  ErrorReg flags, Status2Reg (Crypto1 on), the FIFO level,
                  BitFramingReg, ModeReg (CRC preset), TxModeReg, TxControlReg
                  (antenna on / off), TxASKReg, RFCfgReg (receiver gain in dB),
                  TModeReg and the timer period, VersionReg; the SPI clock (4.00
                  MHz with the library), register reads / writes, frames sent and
                  frames without an answer; the last 14 register accesses
                  (polling reads collapsed, e.g. "R ComIrqReg 40 x1664") and the
                  last 8 card exchanges with their times.
  The tools refuse to start, with the reason, when the reader has no power,
  is in reset, the antenna is off or another test runs. While a tool runs the
  reader's field belongs to it (the panel's cards wait).

THE DEMO SKETCH ON THE SERIAL MONITOR (MFRC522_Demo v1.1)
  HELP              the command list
  STATUS            reads, allowed UIDs, key, antenna, LED, reader version
  ADD [uid]         allow the last card read, or a UID in hex (8 or 14 digits,
                    spaces allowed): "Added A1 B2 C3 D4 (3 allowed)"
  DEL [uid]         remove it: "Removed A1 B2 C3 D4 (2 allowed)"
  DUMP              the next card is printed with PICC_DumpToSerial
  KEY A / KEY B     the key type that opens sector 0 for the block 1 read
  ANTENNA ON / OFF  PCD_AntennaOn / PCD_AntennaOff
Monitor quick buttons in the demo: STATUS, ADD, DEL, DUMP.

EXPECTED MONITOR OUTPUT (U3 and U4 alike)
  TEP MFRC522 RFID Reader Demo v1.1
  Reader firmware: Firmware Version: 0x92 = v2.0
  Authorised: DE AD BE EF, 12 34 56 78
  Click a card on the reader panel...
  Serial Monitor: HELP, STATUS, ADD [uid], DEL [uid], DUMP, KEY A, KEY B, ANTENNA ON / OFF

  Read #1
    UID : DE AD BE EF
    SAK : 0x8
    Type: MIFARE 1KB
    Block 1: 54 45 50 20 52 46 49 44 20 44 45 4D 4F 20 30 39  "TEP RFID DEMO 09"
    -> ACCESS GRANTED

  Read #2
    UID : 04 11 22 33 44 55 66
    SAK : 0x0
    Type: MIFARE Ultralight or Ultralight C
    Pages 4-7: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  "................"
    -> ACCESS DENIED
  Status: 3 reads, 2 allowed, key A, antenna on, LED off, reader 0x92
    allowed: DE AD BE EF
    allowed: 12 34 56 78
  Added A1 B2 C3 D4 (3 allowed)

PROPERTIES (double-click the reader > Edit Properties; the same on Simple and
Advance)
  UID1..UID4    card UIDs: 8 hex characters (4 bytes) or 14 (7 bytes)
  TYPE1..TYPE4  AUTO (8 hex = Classic 1K, 14 = Ultralight - v1.0), 1K, 4K, UL,
                NTAG213 (a 4-byte UID on an Ultralight / NTAG becomes 04 + the 4
                bytes + 80 01; a 7-byte UID on a Classic keeps its first 4)
  KEYA, KEYB    the MIFARE Classic keys every sector trailer starts with, 12 hex
                characters, default FFFFFFFFFFFF
  CHIPVER       VersionReg: 92 (v2.0, default), 91 (v1.0), 88 (FM17522 clone)
The panel style is chosen by the device (Simple / Advance), not by a property.
The Advance window settings (theme, text size, open at Run, size) are on its
Settings page. The demo's Serial Monitors: BAUD 9600, THEME TEPDARK, AUTOOPEN
YES, QUICK1-4 as above (see the Serial Monitor's article for all its
properties).

LINKS.INI (OPTIONAL)
The Help page cards of the Advance device open web pages. To point them
somewhere else without a new DLL, put a text file named links.ini next to
TEPMFRC522.DLL with lines KEY=URL, for example:
  ARTICLE=https://www.theengineeringprojects.com/...
Keys: WEBSITE, FORUM, BUG_REPORT, FEATURE_REQUEST, ARTICLE, USER_GUIDE,
UPDATE_CHECK, DONATE. Only http:// and https:// links are used; lines starting
with # are comments. Cards whose link is not published yet say "Link coming soon".

TROUBLESHOOTING
* "Firmware Version: 0x0 = (unknown)" or "Communication failure": check SCK ->
  D13, MISO -> D12, MOSI -> D11, SDA -> D10, RST -> D9 and the 3V3 / GND
  supply (the PWR LED must be lit).
* No card is detected: the antenna must be on (cyan) - the sketch calls
  PCD_Init(); a sketch that sent ANTENNA OFF / PCD_AntennaOff needs ANTENNA ON.
  Click the card while the simulation runs.
* A card is read once and then not again while it stays: correct - the sketch
  halts it (PICC_HaltA). Click the card again (or Tap it) to place it again.
* A card left selected is found only every other loop: correct - a REQA sends a
  selected card back to IDLE without an answer (call PICC_HaltA when done).
* "Authentication failed: Timeout in communication.": the key the sketch sends
  is not the card's key (KEYA / KEYB, or a trailer your sketch wrote) - the
  Authentication tool shows both keys.
* "MIFARE_Read failed: A MIFARE PICC responded with NAK.": the access bits do not
  allow that read with that key - e.g. key B on a transport card (FF 07 80):
  key B is readable there, so it cannot be used.
* Each loop() without a card takes about 26 ms: correct - the reader's timer
  waits 25 ms for an answer, as on real hardware.
* The Test tab says "Cannot start: ...": the reason is in the message (no
  power, antenna off, another test is running).
* The part is not simulated / no panel: TEPMFRC522.DLL is missing from MODELS
  and from the project folder. No monitor window: TEPSERIALMON.DLL is missing,
  or click OPEN MONITOR on the monitor part.
* Advance: the pop-up does not appear - click OPEN PANEL on the reader board,
  use Proteus's Debug menu, or turn "Open the panel at Run" on its Settings page
  back on.
* Simple: the red X does not close the panel / the board looks like v1.0 - the
  design still holds the v1.0 symbol; replace TEPMFRC522.LIB, delete
  TEPMFRC522.IDX and re-pick the part.

BUG REPORTS AND FEATURE REQUESTS
Please post them in our forum with a screenshot, the Serial Monitor text, the
simulation log and (Advance) the Copy diagnostics text:
  https://www.theengineeringprojects.com/forum/category/mfrc522-proteus-library

SUPPORT US
This library is free. If it saves you time, please support our work:
  https://www.theengineeringprojects.com/donate

WEBSITE
  https://www.theengineeringprojects.com/

LICENCES AND THIRD-PARTY NOTES
* The MFRC522 model (TEPMFRC522.DLL), the symbols and artwork and the TEP
  Serial Monitor Advance (TEPSERIALMON.LIB / .DLL) are made by The Engineering
  Projects. The model is an independent implementation written from NXP's
  published MFRC522 data sheet, the MIFARE Classic / Ultralight / NTAG21x data
  sheets and ISO/IEC 14443-3; it contains no NXP firmware or code. The models
  use only standard Windows libraries; no Visual C++ redistributable is needed.
* TEP Arduino UNO V3 library (ArduinoV3TEP.LIB / .IDX): The Engineering
  Projects, https://www.theengineeringprojects.com/2023/10/arduino-library-for-proteus-v30.html
* MFRC522 Arduino library 1.4.12 by GithubCommunity (miguelbalboa/rfid), shipped
  unmodified in Arduino Code\libraries\MFRC522: the Unlicense (public domain),
  see Arduino Code\libraries\MFRC522\UNLICENSE -
  https://github.com/miguelbalboa/rfid
* Arduino AVR core 1.8.6 (with its SPI library): the .hex file is built from the
  demo sketch, the MFRC522 library and the Arduino AVR core, which includes
  LGPL-licensed code. Its source code is available at
  https://github.com/arduino/ArduinoCore-avr/tree/1.8.6
* NXP, MIFARE, MIFARE Classic, MIFARE Ultralight and NTAG are trademarks of NXP
  B.V.; their use here identifies compatible devices, not endorsement. Proteus
  is a product of Labcenter Electronics and is not included. Arduino is a
  trademark of Arduino SA.

REBUILDING THE FIRMWARE (OPTIONAL)
The HEX file is supplied; Arduino IDE is not needed to run the demo. To edit the
sketch, install the "MFRC522" library (by GithubCommunity) from the Library
Manager or copy Arduino Code\libraries\MFRC522 into your sketchbook libraries
folder, open Arduino Code\MFRC522_Demo\MFRC522_Demo.ino, select Arduino Uno and
use Sketch > Export Compiled Binary. Replace the simulation's MFRC522_Demo.hex
with the exported HEX.

MODEL SCOPE AND LIMITS
Modelled: the SPI interface (mode 0), the registers, FIFO, CRC coprocessor, the
Transceive / MFAuthent / CalcCRC / SoftReset / Mem / Idle commands, the timer
(TModeReg, TPrescalerReg, TReloadReg, TCounterValReg, TAuto), the interrupt
flags and the IRQ pin (polarity, push-pull / open drain), RST (hard reset), the
RF field (TxControlReg), the self test, VersionReg; ISO 14443-3A REQA / WUPA,
ATQA, anticollision and SELECT with one or two cascade levels, HLTA, the card
states; MIFARE Classic authentication, READ, WRITE, INCREMENT, DECREMENT,
RESTORE, TRANSFER with the access conditions; Ultralight / NTAG213 READ (with
roll-over), WRITE, COMPATIBILITY WRITE, GET_VERSION.
Not modelled: Crypto1 on the air (keys are compared directly), several cards in
the field at once (collisions), the RF level, distance and antenna tuning, the
UART / I2C host interfaces of the chip, baud rates above 106 kBd, MIFARE Plus /
DESFire / ISO 14443-4 cards, the NTAG password (PWD_AUTH), counters and
signature, soft power-down timing, card tearing.

VERSION
TEP MFRC522 RFID reader library v1.1 (6 Oct 2026). Devices MFRC522TEP (Simple)
and MFRC522ADVTEP (Advance), files TEPMFRC522.LIB / TEPMFRC522.DLL. Demo sketch
MFRC522_Demo v1.1. Demo monitor: TEP Serial Monitor Advance v1.0.1
(SERIALMONTEP).
v1.0 (29 Sep 2026): first release (MFRC522TEP, TEPMFRC522.DLL, one-UNO demo with
a Virtual Terminal).
